# detail

个人简历模板,其实早就写好了，越简单越好,哈哈哈。
响应式布局，手机，PC都可以看

# start
```
git clone https://gitee.com/dissucc/FeiNiMoShu_ShiJianXu.git

vscode 打开

cd code

cnpm i

npm run start

打包就 npm run build
```

# 栗子

![输入图片说明](https://gitee.com/uploads/images/2018/0108/153103_808d286f_332899.jpeg "TIM截图20180108153022.jpg")

![输入图片说明](https://gitee.com/uploads/images/2018/0108/153113_f2ac79c3_332899.jpeg "TIM截图20180108153032.jpg")